#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>
#include <QTextEdit>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT


public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    bool hasUnsavedChanges(); //simple checker before to exit
    


public slots: // Add this section to declare slots
    
    void open();
    void save();
    void exit();
    void changeFontSize();
    void changeColor();
    void chooseHighlightColor();
    void highlightSelectedText();
    void removeAllHighlights();
    void findText();
    void updateDateTime();
    void showAboutUsDialog();
    void help();
    //void addTab();
    //void removeTab();


private:

   // QTabWidget* tabWidget;
    //QPushButton* addTabAction;
   // QPushButton* removeTabAction;
    QPushButton* dateTimeButton;
    QToolBar* customToolBar;
    QColorDialog colorDialog;//declare dialog instance
    QColor selectedHighlightColor;
    QString savedText;
    Ui::MainWindow *ui;
    QTextEdit *textEdit; //pointer to the entering field
    QAction *openAction; //pointer to "OPEN"
    QAction *saveAction; //pointer to "SAVE"
    QAction *exitAction; //pointer to "EXIT"
    QMenu *fileMenu; //pointer to "MENU"
    QMenu *viewMenu; //pointer to 
    QAction* cutAction;//pointer
    QAction* copyAction;//pointer
    QAction* pasteAction;//pointer
    int font_size;
    QMenu *helpMenu;
    QMenu* tabMenu;
    QPlainTextEdit *textarea;
      // ������� ���������� ���������� dateTimeEdit
    QDateTimeEdit* dateTimeEdit;
    QLabel* dateTimeLabel;
    QTimer* timer;

};
#endif // MAINWINDOW_H
