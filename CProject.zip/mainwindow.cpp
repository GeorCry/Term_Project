#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "QWidget"
#include "qobjectdefs.h"
#include <QColor>
#include <QAction>
#include <QKeySequence>
#include <QMenu>
#include <QLineEdit>
#include <QTextDocument>
#include <QPushButton>
#include <QFileDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QColorDialog>
#include <QLabel>
#include <QTimer>
#include <QTime>
#include <QDateTime>
#include <QTabWidget>
#include <QCoreApplication>
QLineEdit* findLineEdit;
QToolBar* customToolBar;



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), font_size(10)

{
    setGeometry(250, 250, 800, 600);
    // Create a toolbar for custom widgets

   /* tabWidget = new QTabWidget(this);
    setCentralWidget(tabWidget);*/


   // Initialize dateTimeLabel
    dateTimeLabel = new QLabel(this);
    customToolBar = addToolBar("Custom Toolbar");
    customToolBar->addWidget(dateTimeLabel);

    // Create a timer to update date and time every second
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateDateTime()));
    timer->start(1000);


    // Create and add the "Font Size" button to the custom toolbar
    QPushButton* fontSizeButton = new QPushButton(tr("Font Size"), this);
    connect(fontSizeButton, SIGNAL(clicked()), this, SLOT(changeFontSize()));
    customToolBar->addWidget(fontSizeButton);

    // Create and add the "Change color" button to the custom toolbar
    QPushButton* colorButton = new QPushButton(tr("Change color"), this);
    connect(colorButton, SIGNAL(clicked()), this, SLOT(changeColor()));
    customToolBar->addWidget(colorButton);
    textarea = new QPlainTextEdit();
    setCentralWidget(textarea);
    ui->setupUi(this);

    openAction = new QAction(tr("Open"), this);
    openAction->setShortcut(tr("Ctrl+O"));
    connect(openAction, SIGNAL(triggered()), this, SLOT(open()));
    saveAction = new QAction(tr("Save"), this);
     saveAction->setShortcut(tr("Ctrl+S"));
    connect(saveAction, SIGNAL(triggered()), this, SLOT(save()));
    exitAction = new QAction(tr("Exit"), this);
    connect(exitAction, SIGNAL(triggered()), this, SLOT(exit()));
    fileMenu = this->menuBar()->addMenu(tr("&File")); 
    fileMenu->addAction(openAction);
    fileMenu->addAction(saveAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    exitAction->setShortcut(tr("Ctrl+Q"));
    exitAction->setStatusTip("exit program");
    textEdit = new QTextEdit();
    setCentralWidget(textEdit);
    setWindowTitle(tr("Text Editor"));
    //selectedHighlightColor = Qt::yellow;//set an initial default color
    savedText =""; //initialize to an empty string

    QAction* changeFontSize = new QAction(tr("Change Font Size"), this);
   
    qApp->setStyle(QStyleFactory::create("Fusion")); //new formidable and advanced style, old style is bugged

    QMenu* viewMenu = this->menuBar()->addMenu(tr("&View"));

    // Create actions for Cut, Copy, and Paste
    QAction* cutAction = new QAction(tr("Cut"), this);
    cutAction->setShortcut(QKeySequence::Cut);

    QAction* copyAction = new QAction(tr("Copy"), this);
    copyAction->setShortcut(QKeySequence::Copy);

    QAction* pasteAction = new QAction(tr("Paste"), this);
    pasteAction->setShortcut(QKeySequence::Paste);

    // Connect actions to the textEdit object
    connect(cutAction, &QAction::triggered, textEdit, &QTextEdit::cut);
    connect(copyAction, &QAction::triggered, textEdit, &QTextEdit::copy);
    connect(pasteAction, &QAction::triggered, textEdit, &QTextEdit::paste);
    
    // Add actions to the "View" menu
    viewMenu->addAction(cutAction);
    viewMenu->addAction(copyAction);
    viewMenu->addAction(pasteAction);


    findLineEdit = new QLineEdit(this); //line edit for the search term
    customToolBar->addWidget(findLineEdit);

    // Create the button for the search
    QPushButton* findButton = new QPushButton(tr("Find"), this);
    connect(findButton, SIGNAL(clicked()), this, SLOT(findText()));
    customToolBar->addWidget(findButton);

    QPushButton* aboutUsButton = new QPushButton(tr("About Us"), this);
    connect(aboutUsButton, SIGNAL(clicked()), this, SLOT(showAboutUsDialog()));
    customToolBar->addWidget(aboutUsButton);



   // //tabMenu = this->menuBar()->addMenu(tr("&Tabs"));
   //// QPushButton* tabMenuButton = new QPushButton(tr())*/
   // QPushButton* addTabButton = new QPushButton(tr("Add Tab"), this);
   // connect(addTabButton, SIGNAL(clicked()), this, SLOT(addTab()));
   // customToolBar->addWidget(addTabButton);

   // QPushButton* removeTabButton = new QPushButton(tr("Remove Tab"), this);
   // connect(removeTabButton, SIGNAL(clicked()), this, SLOT(removeTab()));
   // customToolBar->addWidget(removeTabButton);

   // QAction* addTabAction = viewMenu->addAction(tr("Add Tab"));
   // QAction* removeTabAction = viewMenu->addAction(tr("Remove Tab"));

   // // Connect addTab and removeTab slots to menu actions or buttons if needed
   // connect(addTabAction, SIGNAL(triggered()), this, SLOT(addTab()));
   // connect(removeTabAction, SIGNAL(triggered()), this, SLOT(removeTab()));


}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::open(){
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("Open file"), "",
                                                    tr("Text files(*.txt);; Files C++(*.cpp *.h)"));
    if(fileName != ""){
        QFile file(fileName);
        if(!file.open(QIODevice::ReadOnly)) {
            QMessageBox::critical(this, tr("Error"), tr("Can't open the file"));
            return;
        }
        QTextStream in(&file);
        textEdit->setText(in.readAll());
        file.close();
    }
}

void MainWindow::save(){
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("Save file"), "",
                                                    tr("Text files(*.txt);; Files C++(*.cpp *.h)"));
    if(fileName != ""){
        QFile file(fileName);
        if(!file.open(QIODevice::WriteOnly)) {
            QMessageBox msgBox; msgBox.setText("Can't save this file"); msgBox.exec();
        }
        else {
            QTextStream stream(&file);
            stream << textEdit->toPlainText();
            stream.flush();
            file.close();
            //update savedText other successful save
            savedText = textEdit->toPlainText();
        }
    }
}

bool MainWindow::hasUnsavedChanges(){
    return textEdit->toPlainText() != savedText;
}
void MainWindow::exit(){
    if(hasUnsavedChanges()){
        QMessageBox msgBox;
        msgBox.setText("Do you want to save unsaved changes?");
        msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        int result  = msgBox.exec();

        if(result == QMessageBox::Save){
            save();
        }
        else if (result == QMessageBox::Discard){
            qApp->quit();
        }
    }
    else{
        QMessageBox msgBox;
        msgBox.setText("Do you want to exit?");
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        if(msgBox.exec() == QMessageBox::Yes){
            qApp->quit();
        }
    }
}

void MainWindow::chooseHighlightColor(){
    QColor newColor = QColorDialog::getColor(Qt::blue, this);
    if(newColor.isValid()){
        selectedHighlightColor = newColor;
    }
}

void MainWindow::showAboutUsDialog() {
    // Display a simple dialog with developer information
    QMessageBox::about(this, tr("About Us"),
        tr("Developers:\n"
            "1. Georgiy Kraynik (Lead Developer)\n"
            "2. Furkan Elcelik (Developer and the Base Optimizer)\n"));
}

void MainWindow::highlightSelectedText(){
    QTextCursor cursor = textEdit->textCursor();
    if(!cursor.hasSelection()){
        return;
    }
    QTextCharFormat format;
    format.setBackground(selectedHighlightColor);//use chosen color from previous step
    cursor.setCharFormat(format);
}


void MainWindow::removeAllHighlights() {
    QTextCursor cursor = textEdit->textCursor();
    if (!cursor.hasSelection()) {
        cursor.select(QTextCursor::Document);  // Select all text
    }

    QTextCharFormat format;
    format.setBackground(Qt::transparent);  // Remove background color
    cursor.setCharFormat(format);
}

void MainWindow::changeFontSize(){
   bool ok;
   int newSize = QInputDialog::getInt(this, tr("Change font size"), tr("Enter new font size:"), font_size, 8, 48, 2, &ok);
   if(ok){
    font_size = newSize;
    QFont font = textEdit->font();
    font.setPointSize(font_size);
    textEdit->setFont(font);
   }
}

void MainWindow::changeColor(){
   QColor newColor = QColorDialog::getColor(textEdit->textColor(), this);
   if(newColor.isValid()){
    textEdit->setTextColor(newColor);
   }
}

void MainWindow::findText() {
    QString searchTerm = findLineEdit->text(); // access to the existing find line edit
    if (!searchTerm.isEmpty()) {
        QTextDocument::FindFlags flags;
        flags.setFlag(QTextDocument::FindFlag::FindWholeWords);
        // Customize search flags if needed (e.g., whole words)

        QTextCursor cursor = textEdit->textCursor();
        cursor.clearSelection(); // Clear existing selections

        QTextDocument* document = textEdit->document();
        QString plainText = document->toPlainText();

        static int lastFoundPosition = 0;

        int startPos = lastFoundPosition;

        startPos = plainText.indexOf(searchTerm, startPos, Qt::CaseInsensitive);

        if (startPos != -1) {
            // Clear existing formatting
            QTextCharFormat clearFormat;
            cursor.setPosition(startPos);
            cursor.setPosition(startPos + searchTerm.length(), QTextCursor::KeepAnchor);
            cursor.setCharFormat(clearFormat);

            // Apply new formatting
            QTextCharFormat highlightFormat;
            highlightFormat.setBackground(Qt::blue);
            cursor.setCharFormat(highlightFormat);

            // Move to the next position after the current match
            lastFoundPosition = startPos + searchTerm.length();
        }
        else {
            // If no match is found, reset to the beginning
            lastFoundPosition = 0;
        }

        // move cursor to the next position
        cursor.setPosition(lastFoundPosition);
        textEdit->setTextCursor(cursor);
    }
    else {
        // Text not found, display a message
        QMessageBox::information(this, tr("Find"), tr("Text not found"));
    }
}

void MainWindow::updateDateTime()
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString dateTimeString = currentDateTime.toString("dd.MM.yyyy hh:mm:ss");
    dateTimeLabel->setText(dateTimeString);
}

void MainWindow::help() {
    QMessageBox::information(this,tr("Help"), tr("Here will be added FAQ and link to the dev's web-site soon"));
}


//void MainWindow::addTab() {
//    if (!tabWidget) {
//        tabWidget = new QTabWidget(this);
//        setCentralWidget(tabWidget);
//    }
//
//    QTextEdit* newTextEdit = new QTextEdit(this);
//    tabWidget->addTab(newTextEdit,tr("New Tab"));
//
//    //optional:
//    tabWidget->setCurrentWidget(newTextEdit);
//}
//
//void MainWindow::removeTab() {
//    int currentIndex = tabWidget->currentIndex();
//    if (currentIndex != -1) {
//        QWidget* currentWidget = tabWidget->widget(currentIndex);
//        tabWidget->removeTab(currentIndex);
//    }
//}


